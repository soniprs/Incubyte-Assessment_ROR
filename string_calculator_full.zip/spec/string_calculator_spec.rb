require_relative '../string_calculator'

RSpec.describe StringCalculator do
  let(:calc) { StringCalculator.new }

  it 'returns 0 for empty string' do
    expect(calc.add("")).to eq(0)
  end

  it 'returns number for single number' do
    expect(calc.add("1")).to eq(1)
  end

  it 'returns sum of two numbers' do
    expect(calc.add("1,5")).to eq(6)
  end

  it 'handles multiple numbers' do
    expect(calc.add("1,2,3,4")).to eq(10)
  end

  it 'handles newlines as delimiters' do
    expect(calc.add("1\n2,3")).to eq(6)
  end

  it 'handles custom delimiters' do
    expect(calc.add("//;\n1;2")).to eq(3)
  end

  it 'handles multi-occurrence custom delimiter' do
    expect(calc.add("//|\n2|4|6")).to eq(12)
  end

  it 'raises exception for negative numbers' do
    expect { calc.add("1,-2,3") }.to raise_error("negative numbers not allowed -2")
  end

  it 'raises exception for multiple negative numbers' do
    expect { calc.add("1,-2,-5,3") }.to raise_error("negative numbers not allowed -2,-5")
  end
end
