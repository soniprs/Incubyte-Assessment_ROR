# String Calculator TDD Kata (Full Version)

This folder includes:
- Ruby implementation of String Calculator
- Full RSpec test suite

## Running Tests

```
gem install rspec
rspec
```
